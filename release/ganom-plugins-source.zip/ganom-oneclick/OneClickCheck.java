package com.protolite.ganom.oneclick;
import java.lang.reflect.*;
import java.util.*;
import net.runelite.api.*;
import net.runelite.api.events.*;
import net.runelite.api.widgets.Widget;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.eventbus.EventBus;
import com.google.inject.Injector;
import com.protolite.ganom.oneclick.config.*;
import com.protolite.ganom.oneclick.clickables.Clickable;
import com.protolite.ganom.oneclick.pojos.ItemData;
public class OneClickCheck {
 static Object[] selection;static int calls;static OneClick plugin;
 static <T>T mock(Class<T> c,java.util.function.BiFunction<String,Object[],Object> fn){return c.cast(Proxy.newProxyInstance(c.getClassLoader(),new Class[]{c},(p,m,a)->{Object v=fn.apply(m.getName(),a);if(v!=null)return v;if(m.getReturnType()==boolean.class)return false;if(m.getReturnType()==int.class)return 0;return null;}));}
 static void set(Object o,String name,Object value)throws Exception{for(Class<?> c=o.getClass();c!=null;c=c.getSuperclass())try{Field f=c.getDeclaredField(name);f.setAccessible(true);f.set(o,value);return;}catch(NoSuchFieldException ignored){}throw new NoSuchFieldException(name);}
 public static void main(String[]args)throws Exception {
  plugin=new OneClick();MenuEntry entry=mock(MenuEntry.class,(n,a)->null);
  Widget spell=mock(Widget.class,(n,a)->n.equals("getId")?0x00da002f:n.equals("getName")?"High Level Alchemy":null);
  ItemContainer inventory=mock(ItemContainer.class,(n,a)->n.equals("getItems")?new Item[0]:null);
  Client client=mock(Client.class,(n,a)->{switch(n){case "getGameState":return GameState.LOGGED_IN;case "getSkillExperience":return 200;case "getItemContainer":return inventory;case "getWidget":return spell;case "menuAction":selection=a;plugin.onMenuOptionClicked(new MenuOptionClicked(entry));return null;}return null;});
  OneClickConfig config=mock(OneClickConfig.class,(n,a)->{switch(n){case "getSkillingOneClicks":return Set.of(Skilling.values());case "getCombatOneClicks":return Set.of(Combat.values());case "getCustomOneClicks":return Set.of(Custom.values());case "getMinigameOneClicks":return Set.of(Minigame.values());case "getCustomIds":return "";}return null;});
  Injector injector=mock(Injector.class,(n,a)->{if(!n.equals("getInstance"))return null;try{var constructor=((Class<?>)a[0]).getDeclaredConstructor();constructor.setAccessible(true);Object instance=constructor.newInstance();set(instance,"client",client);set(instance,"plugin",plugin);set(instance,"config",config);return instance;}catch(Exception e){throw new RuntimeException(e);}});
  set(plugin,"client",client);set(plugin,"config",config);set(plugin,"injector",injector);set(plugin,"clientThread",new ClientThread(){@Override public void invoke(Runnable r){r.run();}});
  plugin.startUp();if(selection!=null)throw new AssertionError("startup executed action");
  EventBus eventBus=new EventBus();eventBus.register(plugin);
  Field f=OneClick.class.getDeclaredField("clickable");f.setAccessible(true);List<Clickable> clickables=(List<Clickable>)f.get(plugin);
  if(clickables.size()!=Combat.values().length+Skilling.values().length+Custom.values().length+Minigame.values().length)throw new AssertionError("missing mode");
  int modes=clickables.size();clickables.clear();Clickable helper=new Clickable(){public boolean isValidEntry(MenuEntryAdded e){return false;}public boolean isValidClick(MenuOptionClicked e){calls++;return false;}};
  set(helper,"client",client);set(helper,"plugin",plugin);clickables.add(helper);
  plugin.getInventory().add(new ItemData(123,1,4,"Test Item",null));
  if(helper.findItem("test item")==null)throw new AssertionError("case-insensitive item lookup");
  helper.setSelectedWidget(new ItemData(123,1,4,"Test item",null));
  if((int)selection[0]!=4||(int)selection[1]!=9764864||(int)selection[4]!=123||selection[2]!=MenuAction.WIDGET_TARGET||calls!=0)throw new AssertionError("native item selection/recursion guard");
  helper.setSelectSpell(0x00da002f);if((int)selection[1]!=0x00da002f||calls!=0)throw new AssertionError("spell selection");
  plugin.onMenuOptionClicked(new MenuOptionClicked(entry));if(calls!=1)throw new AssertionError("guard did not reset");
  eventBus.post(new StatChanged(Skill.MAGIC,265,99,99));if(plugin.getHighAlchTicks()!=4)throw new AssertionError("XP event delivery");
  plugin.onGameStateChanged(new GameStateChanged());if(plugin.getHighAlchTicks()!=0||!plugin.getInventory().isEmpty())throw new AssertionError("logout reset");
  eventBus.unregister(plugin);plugin.shutDown();
  eventBus.post(new StatChanged(Skill.MAGIC,330,99,99));if(plugin.getHighAlchTicks()!=0)throw new AssertionError("unregistered subscriber still received event");
  System.out.println("PASS: all "+modes+" activity handlers construct; startup has no actions; real RuneLite EventBus registration, XP delivery and unregistration work; native item/spell selection and reentrancy guard work; XP cooldown/logout reset. No real game actions executed.");
 }
}

