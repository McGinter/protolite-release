package com.protolite.ganom.oneclick.clickables.minigames;

import net.runelite.api.MenuAction;
import net.runelite.api.events.MenuEntryAdded;
import net.runelite.api.events.MenuOptionClicked;
import com.protolite.ganom.oneclick.clickables.Clickable;

public class TroubleBrewing extends Clickable
{
	@Override
	public boolean isValidEntry(MenuEntryAdded event)
	{
		if (event.getType() != MenuAction.EXAMINE_OBJECT.getId() || event.getMenuEntry().isForceLeftClick() ||
			!event.getTarget().toLowerCase().contains("hopper") || findItem(1929) == null)
		{
			return false;
		}
		client.createMenuEntry(client.getMenuEntries().length)
			.setOption("Use")
			.setTarget("<col=ff9040>Water Bucket<col=ffffff> -> " + event.getTarget())
			.setType(MenuAction.WIDGET_TARGET_ON_GAME_OBJECT)
			.setIdentifier(event.getIdentifier())
			.setParam0(event.getActionParam0())
			.setParam1(event.getActionParam1())
			.setForceLeftClick(true);
		return true;
	}

	@Override
	public boolean isValidClick(MenuOptionClicked event)
	{
		return event.getMenuTarget().contains("<col=ff9040>Water Bucket<col=ffffff> -> ") && updateSelectedItem(1929);
	}
}



