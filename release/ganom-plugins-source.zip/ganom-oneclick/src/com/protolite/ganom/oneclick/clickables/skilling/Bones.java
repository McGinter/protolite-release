package com.protolite.ganom.oneclick.clickables.skilling;

import com.google.common.collect.ImmutableSet;
import java.util.Set;
import net.runelite.api.ItemID;
import net.runelite.api.MenuAction;
import net.runelite.api.events.MenuEntryAdded;
import net.runelite.api.events.MenuOptionClicked;
import com.protolite.ganom.oneclick.clickables.Clickable;

public class Bones extends Clickable
{
	private static final Set<Integer> BONE_SET = ImmutableSet.of(
		ItemID.BONES, ItemID.WOLF_BONE, ItemID.BURNT_BONES, ItemID.MONKEY_BONES, ItemID.BAT_BONES,
		ItemID.JOGRE_BONE, ItemID.BIG_BONES, ItemID.ZOGRE_BONE, ItemID.SHAIKAHAN_BONES, ItemID.BABYDRAGON_BONES,
		ItemID.WYRM_BONES, ItemID.DRAGON_BONES, ItemID.DRAKE_BONES, ItemID.FAYRG_BONES, ItemID.LAVA_DRAGON_BONES,
		ItemID.RAURG_BONES, ItemID.HYDRA_BONES, ItemID.DAGANNOTH_BONES, ItemID.OURG_BONES, ItemID.SUPERIOR_DRAGON_BONES,
		ItemID.WYVERN_BONES
	);

	@Override
	public boolean isValidEntry(MenuEntryAdded event)
	{
		if (event.getType() != MenuAction.GAME_OBJECT_FIRST_OPTION.getId() ||
			event.getMenuEntry().isForceLeftClick() ||
			!event.getOption().toLowerCase().contains("pray") ||
			!event.getTarget().toLowerCase().contains("altar") ||
			findItemWithIds(BONE_SET) == null)
		{
			return false;
		}
		client.createMenuEntry(client.getMenuEntries().length)
			.setOption("Use")
			.setTarget("<col=ff9040>Bones<col=ffffff> -> " + event.getTarget())
			.setType(MenuAction.WIDGET_TARGET_ON_GAME_OBJECT)
			.setIdentifier(event.getIdentifier())
			.setParam0(event.getActionParam0())
			.setParam1(event.getActionParam1())
			.setForceLeftClick(true);
		return true;
	}

	@Override
	public boolean isValidClick(MenuOptionClicked event)
	{
		return event.getMenuTarget().contains("<col=ff9040>Bones<col=ffffff> -> ") &&
			event.getMenuTarget().toLowerCase().contains("altar") && updateSelectedItem(BONE_SET);
	}
}



