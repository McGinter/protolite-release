package com.protolite.ganom.oneclick.config;

import com.google.inject.Injector;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Getter;
import com.protolite.ganom.oneclick.clickables.Clickable;
import com.protolite.ganom.oneclick.clickables.skilling.Birdhouses;
import com.protolite.ganom.oneclick.clickables.skilling.Bones;
import com.protolite.ganom.oneclick.clickables.skilling.HighAlch;
import com.protolite.ganom.oneclick.clickables.skilling.Karams;
import com.protolite.ganom.oneclick.clickables.skilling.Runes;
import com.protolite.ganom.oneclick.clickables.skilling.Tiaras;
import com.protolite.ganom.oneclick.clickables.skilling.farming.FarmingRun;
import com.protolite.ganom.oneclick.clickables.skilling.farming.TitheFarm;

@Getter
@AllArgsConstructor
public enum Skilling
{
	BIRDHOUSES(Birdhouses.class),
	BONES(Bones.class),
	FARMING_RUN(FarmingRun.class),
	HIGH_ALCH(HighAlch.class),
	KARAMBWANS(Karams.class),
	RUNES(Runes.class),
	TIARA(Tiaras.class),
	TITHE_FARM(TitheFarm.class),
	;

	private final Class<? extends Clickable> clazz;

	public static List<Clickable> createInstances(Set<Skilling> set, Injector injector)
	{
		return set.stream()
			.filter(Objects::nonNull)
			.map(skilling -> injector.getInstance(skilling.getClazz()))
			.collect(Collectors.toList());
	}
}



