# [G] OneClick 0.1.0
Port of Ganom/ExternalPlugins OneClick, GPL-3.0.
Upstream: https://github.com/Ganom/ExternalPlugins/tree/master/OneClick

The 14 original activity handlers are retained: custom inventory item combinations; Slayer finishers and Vorkath; birdhouses, bones, farming runs, high alchemy, karambwans, combination runes, tiaras and Tithe Farm; Barbarian Assault healers, Trouble Brewing and Mage Training Arena. Select the activity categories in settings. Entries are produced when their actual game objects, items or NPCs match. Those activity-specific location checks identify the activity; they are not a global area blacklist. The plugin starts disabled and enabling alone generates no gameplay action.

Removed OpenOSRS selected-spell setters are replaced with native RuneLite widget-selection menu actions, with a reentrancy guard. Updated live spell component IDs are pinned from RuneLite 1.13.1; unsupported internal client imports were replaced by a local BSD-attributed Mage Training Arena item enum. XP-drop events use StatChanged, inventory is loaded when enabling/login, state clears on logout, zero custom-item placeholder IDs are ignored, and item names match case-insensitively. Obsolete inventory client script 6009 is replaced with widget revalidation.

OneClickCheck instantiates all 14 handlers and tests idle startup, native item/spell selection against a fake client, recursion protection, name matching, XP cooldown and logout cleanup. No real game actions are performed by the tests. These checks do not prove that every old activity/object ID still matches current game content; each activity needs live testing.

Build with build.ps1 and JDK 17. Shared ../ganom-dependencies contains the official RuneLite 1.13.1 compile API and Lombok 1.18.36; runtime dependencies come from ../classpath-files.txt and the user's RuneLite repository2 cache. Output targets Java 11. Full GPL license and the BSD MTA source header are preserved.

Corresponding source: https://github.com/McGinter/protolite-release/raw/refs/heads/master/release/ganom-plugins-source.zip
