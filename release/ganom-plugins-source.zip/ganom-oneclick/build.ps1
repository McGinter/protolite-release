param([string]$JdkDirectory=(Join-Path $env:ProgramFiles 'Java/jdk-17'),[string]$Dependencies=(Join-Path $env:USERPROFILE '.runelite/repository2'))
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$parent=Split-Path $root -Parent
$classpath=(Get-Content "$parent/classpath-files.txt" | ForEach-Object {Join-Path $Dependencies $_}) -join ';'
$classpath="$parent/ganom-dependencies/runelite-api-1.13.1.jar;"+$classpath
$lombok="$parent/ganom-dependencies/lombok-1.18.36.jar"
New-Item -ItemType Directory -Force "$root/classes","$root/dist" | Out-Null
$sources=Get-ChildItem "$root/src" -Recurse -Filter '*.java' | ForEach-Object {'"'+$_.FullName.Replace('\','/')+'"'}
[IO.File]::WriteAllLines("$root/sources.txt",[string[]]$sources)
& "$JdkDirectory/bin/javac.exe" --release 11 -encoding UTF-8 -cp "$classpath;$lombok" -processorpath $lombok -d "$root/classes" "@$root/sources.txt" 2> "$root/compile.log"
if($LASTEXITCODE){Get-Content "$root/compile.log";throw 'Compilation failed'}
Copy-Item "$root/resources/*" "$root/classes" -Recurse -Force
& "$JdkDirectory/bin/jar.exe" "-J-Djava.io.tmpdir=$root/dist" --create --file "$root/dist/ganom-oneclick.jar" --manifest "$root/resources/META-INF/MANIFEST.MF" -C "$root/classes" .
if($LASTEXITCODE){throw 'Packaging failed'}
Write-Output 'Built ganom-oneclick.jar'
