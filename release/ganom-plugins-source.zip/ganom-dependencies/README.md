Build dependencies only; not embedded in runtime plugins.
RuneLite compile API 1.13.1: https://repo.runelite.net/net/runelite/runelite-api/1.13.1/runelite-api-1.13.1.jar
Lombok 1.18.36: https://repo.maven.apache.org/maven2/org/projectlombok/lombok/1.18.36/lombok-1.18.36.jar
Both plugins use the already installed RuneLite 1.13.1 runtime API.
