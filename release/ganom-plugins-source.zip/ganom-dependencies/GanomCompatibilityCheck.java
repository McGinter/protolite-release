import java.util.*;
import java.util.jar.*;
import java.lang.reflect.*;
import jdk.internal.org.objectweb.asm.*;
import net.runelite.client.plugins.PluginDescriptor;

public class GanomCompatibilityCheck {
    static int checked,failures;
    static boolean hasMethod(Class<?> c,String name,String descriptor) {
        if(name.equals("<init>"))return Arrays.stream(c.getDeclaredConstructors()).anyMatch(m->jdk.internal.org.objectweb.asm.Type.getConstructorDescriptor(m).equals(descriptor));
        for(Method method:c.getDeclaredMethods())if(method.getName().equals(name)&&jdk.internal.org.objectweb.asm.Type.getMethodDescriptor(method).equals(descriptor))return true;
        if(c.getSuperclass()!=null && hasMethod(c.getSuperclass(),name,descriptor))return true;
        for(Class<?> type:c.getInterfaces())if(hasMethod(type,name,descriptor))return true;
        return false;
    }
    public static void main(String[] args)throws Exception {
        for(String path:args)try(JarFile jar=new JarFile(path)) {
            for(JarEntry entry:Collections.list(jar.entries()))if(entry.getName().endsWith(".class")) {
                new ClassReader(jar.getInputStream(entry)).accept(new ClassVisitor(Opcodes.ASM8) {
                    @Override public MethodVisitor visitMethod(int a,String n,String d,String s,String[] e) {
                        return new MethodVisitor(Opcodes.ASM8) {
                            @Override public void visitMethodInsn(int op,String owner,String name,String descriptor,boolean iface) {
                                if(!owner.startsWith("net/runelite/"))return;
                                checked++;
                                try{if(!hasMethod(Class.forName(owner.replace('/','.'),false,GanomCompatibilityCheck.class.getClassLoader()),name,descriptor))throw new NoSuchMethodException(owner+"."+name+descriptor);}
                                catch(ReflectiveOperationException ex){failures++;System.out.println(ex);}
                            }
                        };
                    }
                },ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
                if(entry.getName().endsWith("/OneClick.class") || entry.getName().endsWith("/CustomSwapper.class")) {
                    Class<?> plugin=Class.forName(entry.getName().replace('/','.').replace(".class",""));
                    PluginDescriptor descriptor=plugin.getAnnotation(PluginDescriptor.class);
                    if(descriptor==null || !descriptor.name().contains("color=#F472B6>G") || descriptor.enabledByDefault())throw new AssertionError("Descriptor");
                    plugin.getDeclaredConstructor().newInstance();
                    System.out.println("Constructed "+descriptor.name());
                }
            }
        }
        System.out.println("Checked "+checked+" RuneLite call sites; "+failures+" incompatible calls");
        if(failures>0)throw new AssertionError("Compatibility failures");
    }
}



