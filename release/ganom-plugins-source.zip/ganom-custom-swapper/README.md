# [G] Custom Swapper 0.1.0
Port of Ganom/ExternalPlugins CustomSwapper (2019-2020), GPL-3.0.
Upstream: https://github.com/Ganom/ExternalPlugins/tree/master/CustomSwapper

There are 20 sequence slots and matching hotkeys. Enter one value:command per line. Supported commands: equip, remove, clean (positive item IDs); prayer (prayer name); cast (spell name); enable (special attack). For example the format is <item ID>:equip, Protect from Magic:prayer, or <spell name>:cast. Numeric packed widget IDs or group:child:cast are also accepted for prayer/spell identification. Empty lines and // comments are ignored, and repeated values are preserved in order. ::copycs copies your current equipped item IDs as equip lines to the clipboard.

Enabling registers hotkeys only. A configured hotkey starts one sequence; additional presses while busy are ignored. Escape, logout, loss of game-canvas focus and disabling the plugin stop the sequence. Game reads/widget resolution run on ClientThread, while synthetic key and mouse events are delivered to RuneLite's focused canvas on AWT. Desktop cursor movement and global Robot key presses are not used. Tab changes use your in-game F-key bindings and require confirmation that the intended tab opened before resolving current widget bounds. Missing targets report in local chat. Active-prayer check and optional return to inventory remain supported. Min/max delay settings use their actual inclusive bounds.

The plugin can execute multiple gameplay inputs per hotkey. No sequence is scheduled or executed by enabling the plugin. Defaults contain no sequences or hotkeys. This was authorized specifically as an exception to ProtoLite's usual manual-only plugins. Tests use mocks and do not dispatch real input; live testing is still required.

Build with build.ps1, JDK 17 and ../classpath-files.txt dependencies in the RuneLite repository2 cache. Output targets Java 11. MacroCheck.java tests parser ordering/duplicates, invalid input, widget traversal, scaled coordinates, tab bindings, idle startup, cancellation and listener cleanup.

Corresponding source: https://github.com/McGinter/protolite-release/raw/refs/heads/master/release/ganom-plugins-source.zip
