# [G] Custom Swapper 0.2.1
Port of Ganom/ExternalPlugins CustomSwapper (2019-2020), GPL-3.0.
Upstream: https://github.com/Ganom/ExternalPlugins/tree/master/CustomSwapper

There are 10 sequence slots and matching hotkeys. Enter one value:command per line. Supported commands: equip, remove, clean (positive item IDs); prayer (prayer name); cast (spell name); enable (special attack). For example the format is <item ID>:equip, Protect from Magic:prayer, or <spell name>:cast. Numeric packed widget IDs or group:child:cast are also accepted for prayer/spell identification. Empty lines and // comments are ignored, and repeated values are preserved in order. Enable the plugin and open its normal settings page. Copy worn gear copies each equipped item as an ID:equip line, ready to paste into a swap entry. Rename sets edits all ten display names and updates both swap and hotkey labels. No extra sidebar icon is added. ::copycs remains available as an alternative. Empty equipment leaves the clipboard unchanged. The original first-ten configuration keys are retained; former slots 11�20 are no longer displayed or registered.

Enabling registers hotkeys only. A configured hotkey starts one sequence; additional presses while busy are ignored. Logout, loss of game-canvas focus and disabling the plugin stop the sequence. Game reads/widget resolution run on ClientThread, while synthetic key and mouse events are delivered to RuneLite's focused canvas on AWT. Desktop cursor movement and global Robot key presses are not used. Tab changes use your in-game F-key bindings and require confirmation that the intended tab opened before resolving current widget bounds. Missing targets report in local chat. Active-prayer check and optional return to inventory remain supported. Min/max delay settings use their actual inclusive bounds.

The plugin can execute multiple gameplay inputs per hotkey. No sequence is scheduled or executed by enabling the plugin. Defaults contain no sequences or hotkeys. This was authorized specifically as an exception to ProtoLite's usual manual-only plugins. Tests use mocks and do not dispatch real input; live testing is still required.

Build with build.ps1, JDK 17 and ../classpath-files.txt dependencies in the RuneLite repository2 cache. Output targets Java 11. MacroCheck.java tests parser ordering/duplicates, invalid input, widget traversal, scaled coordinates, tab bindings, idle startup, cancellation and listener cleanup.

Corresponding source: https://github.com/McGinter/protolite-release/raw/refs/heads/master/release/ganom-plugins-source.zip

SettingsCheck.java verifies the ten-entry limit, gear export round-trip through the parser, controls attached to the real RuneLite settings panel, saved names, matching labels and button callbacks without touching the clipboard.

Escape has no cancellation listener and remains available for the in-game inventory binding.

Equip actions skip items already worn, so overlapping gear sets continue rather than stopping. Busy hotkey presses report that a swap is already running; unavailable targets report the exact value:command.

Equipment and removal actions must be confirmed in the equipment container before the next action. Confirmation polls every 10 ms on the worker thread, times out after 1.5 seconds and never retries a click. The sequence has a 60-second limit. A held hotkey starts at most one sequence until released; losing focus resets the held-key state. Synthetic tab keys cannot trigger another sequence.
