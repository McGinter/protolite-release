param([string]$JdkDirectory=(Join-Path $env:ProgramFiles 'Java\jdk-17'), [string]$Dependencies=(Join-Path $env:USERPROFILE '.runelite\repository2'))
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$moduleRoot=Split-Path $root -Parent
$classpath=(Get-Content -LiteralPath "$moduleRoot\classpath-files.txt" | ForEach-Object {Join-Path $Dependencies $_}) -join ';'
New-Item -ItemType Directory -Path "$root\classes","$root\dist" -Force | Out-Null
$sources=Get-ChildItem "$root\src" -Recurse -Filter '*.java' | ForEach-Object {'"'+$_.FullName.Replace('\','/')+'"'}
[IO.File]::WriteAllLines("$root\sources.txt",[string[]]$sources)
& "$JdkDirectory\bin\javac.exe" -proc:none --release 11 -cp $classpath -d "$root\classes" "@$root\sources.txt"
if($LASTEXITCODE -ne 0){throw 'Compilation failed'}
Copy-Item -Path "$root\resources\*" -Destination "$root\classes" -Recurse -Force
& "$JdkDirectory\bin\jar.exe" "-J-Djava.io.tmpdir=$root\dist" --create --file "$root\dist\ganom-custom-swapper.jar" --manifest "$root\resources\META-INF\MANIFEST.MF" -C "$root\classes" .
if($LASTEXITCODE -ne 0){throw 'Packaging failed'}
Write-Output 'Built ganom-custom-swapper.jar'



