package com.protolite.ganom.customswapper;

import java.awt.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.function.*;
import javax.swing.*;

/** Adds controls only to this plugin's existing RuneLite settings form. No navigation entry. */
final class SwapperSettingsControls {
    private final Runnable copy;
    private final IntFunction<String> names;
    private final BiConsumer<Integer,String> saveName;
    private final Map<JPanel,JPanel> mounted=new WeakHashMap<>();
    private final javax.swing.Timer timer=new javax.swing.Timer(400,e->scan());
    SwapperSettingsControls(Runnable copy,IntFunction<String> names,BiConsumer<Integer,String> saveName){this.copy=copy;this.names=names;this.saveName=saveName;}
    void start(){SwingUtilities.invokeLater(()->{timer.start();scan();});}
    void stop(){SwingUtilities.invokeLater(()->{timer.stop();for(var entry:mounted.entrySet()){entry.getKey().remove(entry.getValue());restore(entry.getKey());entry.getKey().revalidate();entry.getKey().repaint();}mounted.clear();});}
    private void scan(){for(var iterator=mounted.entrySet().iterator();iterator.hasNext();){var entry=iterator.next();if(!entry.getKey().isDisplayable()){entry.getKey().remove(entry.getValue());restore(entry.getKey());iterator.remove();}}for(Window window:Window.getWindows())if(window.isVisible())visit(window);}
    private void visit(Container root){
        if(root.getClass().getName().equals("net.runelite.client.plugins.config.ConfigPanel")){
            try{Field field=root.getClass().getDeclaredField("pluginConfig");field.setAccessible(true);Object descriptor=field.get(root);if(descriptor==null)return;Field config=descriptor.getClass().getDeclaredField("config");config.setAccessible(true);if(!(config.get(descriptor) instanceof CustomSwapperConfig))return;Field main=root.getClass().getDeclaredField("mainPanel");main.setAccessible(true);enhance((JPanel)main.get(root));}
            catch(ReflectiveOperationException error){timer.stop();org.slf4j.LoggerFactory.getLogger(SwapperSettingsControls.class).warn("Custom Swapper settings controls unavailable in this RuneLite version",error);}
            return;
        }
        for(Component child:root.getComponents())if(child instanceof Container&&child.isVisible())visit((Container)child);
    }
    void enhance(JPanel main){
        JPanel controls=mounted.get(main);
        if(controls==null||controls.getParent()!=main){
            controls=new JPanel(new GridLayout(2,1,0,5));controls.setOpaque(false);
            JButton copyButton=new JButton("Copy worn gear");copyButton.setToolTipText("Copy equipped item IDs as one ID:equip line per item, ready to paste into a swap entry.");copyButton.addActionListener(e->copy.run());controls.add(copyButton);
            JButton renameButton=new JButton("Rename sets...");renameButton.addActionListener(e->rename(main));controls.add(renameButton);main.add(controls,0);mounted.put(main,controls);main.revalidate();main.repaint();
        }
        labels(main);
    }
    private void rename(Component parent){
        JPanel fields=new JPanel(new GridLayout(10,2,5,5));JTextField[] values=new JTextField[10];
        for(int i=0;i<10;i++){fields.add(new JLabel("Set "+(i+1)));values[i]=new JTextField(names.apply(i),15);fields.add(values[i]);}
        if(JOptionPane.showConfirmDialog(parent,fields,"Rename swap sets",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        String[] updated=new String[10];for(int i=0;i<10;i++)updated[i]=values[i].getText();saveNames(updated);
        for(JPanel main:mounted.keySet()){labels(main);main.revalidate();main.repaint();}
    }
    void saveNames(String[] values){if(values.length!=10)throw new IllegalArgumentException("Ten set names required");for(int i=0;i<10;i++){String name=values[i].trim();saveName.accept(i,name.isEmpty()?"Set "+(i+1):name.substring(0,Math.min(name.length(),64)));}}
    private void labels(Container root){
        for(Component child:root.getComponents()){
            if(child instanceof JLabel){JLabel label=(JLabel)child;String original=(String)label.getClientProperty("protolite.swap.original");if(original==null)original=label.getText();
                for(int i=0;i<10;i++){boolean swap=("Swap Set: "+CustomSwapper.SETS[i]).equals(original);if(swap||("Execute "+CustomSwapper.SETS[i]).equals(original)){label.putClientProperty("protolite.swap.original",original);label.setText((swap?"Swap: ":"Execute ")+names.apply(i));label.setToolTipText("Set "+(i+1)+" — change its name with Rename sets");break;}}
            }
            if(child instanceof Container)labels((Container)child);
        }
    }
    private void restore(Container root){for(Component child:root.getComponents()){if(child instanceof JLabel){JLabel label=(JLabel)child;String original=(String)label.getClientProperty("protolite.swap.original");if(original!=null){label.setText(original);label.putClientProperty("protolite.swap.original",null);}}if(child instanceof Container)restore((Container)child);}}
}
