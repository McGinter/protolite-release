package com.protolite.ganom.customswapper;
import java.util.StringJoiner;
import net.runelite.api.Item;
final class EquipmentExport {
    static String format(Item[] items){StringJoiner lines=new StringJoiner("\n");if(items!=null)for(Item item:items)if(item!=null&&item.getId()>0&&item.getQuantity()>0)lines.add(item.getId()+":equip");return lines.toString();}
}
