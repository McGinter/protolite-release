package com.protolite.ganom.customswapper;

import java.util.*;
import java.util.function.IntUnaryOperator;

/** Tracks final slot targets without waiting between clicks. */
final class EquipmentPlan {
    private final Map<Integer,Integer> targets=new LinkedHashMap<>();
    private boolean twoHanded;
    void equip(int slot,int id,boolean twoHandedItem){
        if(slot==3){twoHanded=twoHandedItem;if(twoHandedItem)targets.put(5,-1);}
        if(slot==5&&twoHanded){targets.put(3,-1);twoHanded=false;}
        targets.put(slot,id);
    }
    void remove(int slot,int id){if(!targets.containsKey(slot)||targets.get(slot)==id)targets.put(slot,-1);if(slot==3)twoHanded=false;}
    List<String> missing(IntUnaryOperator equipped){
        List<String> missing=new ArrayList<>();
        for(Map.Entry<Integer,Integer> target:targets.entrySet())if(equipped.applyAsInt(target.getKey())!=target.getValue())missing.add(target.getValue()<0?"slot "+target.getKey()+" should be empty":target.getValue()+":equip");
        return missing;
    }
    boolean isEmpty(){return targets.isEmpty();}
}
