/*
 * Copyright (c) 2019-2020, ganom <https://github.com/Ganom>
 * All rights reserved.
 * Licensed under GPL3, see LICENSE for the full scope.
 */
package com.protolite.ganom.customswapper;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.ConfigSection;
import net.runelite.client.config.Keybind;

@ConfigGroup("customSwapper")
public interface CustomSwapperConfig extends Config
{
	@ConfigSection(			name = "Config",
			description = "",
			position = 0
	)
	String config = "Config";

	@ConfigItem(
			keyName = "swapBack",
			name = "Swap back to inventory",
			description = "Once finished with a swap, should it swap back to inventory?",
			section = config,
			position = 1
	)
	default boolean swapBack()
	{
		return true;
	}

	@ConfigItem(
			keyName = "enablePrayCheck",
			name = "Active Prayer Check",
			description = "Enabling this will make it so you can't toggle prayers if they're on.",
			section = config,
			position = 2
	)
	default boolean enablePrayCheck()
	{
		return true;
	}

	@ConfigItem(
			keyName = "randLow",
			name = "Minimum click delay (ms)",
			description = "Delay between clicks. 60-70 ms gives eight clicks about 0.5 seconds of configured delay; game processing and tab opening add time.",
			section = config,
			position = 3
	)
	default int randLow()
	{
		return 70;
	}

	@ConfigItem(
			keyName = "randLower",
			name = "Maximum click delay (ms)",
			description = "Delay between clicks. 60-70 ms gives eight clicks about 0.5 seconds of configured delay; game processing and tab opening add time.",
			section = config,
			position = 4
	)
	default int randHigh()
	{
		return 80;
	}

    @ConfigItem(keyName="chatMessages",name="Show chat messages",description="Enable or disable all Custom Swapper chat messages, including timing, errors and equipment checks.",section=config,position=5)
    default boolean chatMessages(){return true;}

    @ConfigItem(keyName="reportTiming",name="Report swap timing",description="Print click count and actual send duration in local chat. This measures client dispatch, not server completion. Requires Show chat messages.",section=config,position=6)
    default boolean reportTiming(){return true;}

	@ConfigSection(
			position = 1,
			name = "Main Config",
			description = ""
	)
	String mainConfig = "Main Config";

	@ConfigItem(
			keyName = "customSwapOne",
			name = "Swap Set: One",
			description = "",
			position = 1,
			section = mainConfig
	)
	default String customSwapOne()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapTwo",
			name = "Swap Set: Two",
			description = "",
			position = 2,
			section = mainConfig
	)
	default String customSwapTwo()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapThree",
			name = "Swap Set: Three",
			description = "",
			position = 3,
			section = mainConfig
	)
	default String customSwapThree()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapFour",
			name = "Swap Set: Four",
			description = "",
			position = 4,
			section = mainConfig
	)
	default String customSwapFour()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapFive",
			name = "Swap Set: Five",
			description = "",
			position = 5,
			section = mainConfig
	)
	default String customSwapFive()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapSix",
			name = "Swap Set: Six",
			description = "",
			position = 6,
			section = mainConfig
	)
	default String customSwapSix()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapSeven",
			name = "Swap Set: Seven",
			description = "",
			position = 7,
			section = mainConfig
	)
	default String customSwapSeven()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapEight",
			name = "Swap Set: Eight",
			description = "",
			position = 8,
			section = mainConfig
	)
	default String customSwapEight()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapNine",
			name = "Swap Set: Nine",
			description = "",
			position = 9,
			section = mainConfig
	)
	default String customSwapNine()
	{
		return "";
	}

	@ConfigItem(
			keyName = "customSwapTen",
			name = "Swap Set: Ten",
			description = "",
			position = 10,
			section = mainConfig
	)
	default String customSwapTen()
	{
		return "";
	}

	@ConfigSection(
			position = 21,
			name = "Hotkeys",
			description = ""
	)
	String hotkeys = "Hotkeys";

	@ConfigItem(
			keyName = "customOne",
			name = "Execute One",
			description = "",
			position = 22,
			section = hotkeys
	)
	default Keybind customOne()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customTwo",
			name = "Execute Two",
			description = "",
			position = 23,
			section = hotkeys
	)
	default Keybind customTwo()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customThree",
			name = "Execute Three",
			description = "",
			position = 24,
			section = hotkeys
	)
	default Keybind customThree()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customFour",
			name = "Execute Four",
			description = "",
			position = 25,
			section = hotkeys
	)
	default Keybind customFour()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customFive",
			name = "Execute Five",
			description = "",
			position = 26,
			section = hotkeys
	)
	default Keybind customFive()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customSix",
			name = "Execute Six",
			description = "",
			position = 27,
			section = hotkeys
	)
	default Keybind customSix()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customSeven",
			name = "Execute Seven",
			description = "",
			position = 28,
			section = hotkeys
	)
	default Keybind customSeven()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customEight",
			name = "Execute Eight",
			description = "",
			position = 29,
			section = hotkeys
	)
	default Keybind customEight()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customNine",
			name = "Execute Nine",
			description = "",
			position = 30,
			section = hotkeys
	)
	default Keybind customNine()
	{
		return Keybind.NOT_SET;
	}

	@ConfigItem(
			keyName = "customTen",
			name = "Execute Ten",
			description = "",
			position = 31,
			section = hotkeys
	)
	default Keybind customTen()
	{
		return Keybind.NOT_SET;
	}

	// Names are edited with the Rename sets button in this settings form.
	@ConfigItem(keyName="setNameOne", name="Set 1 name", description="Custom display name", hidden=true)
	default String setNameOne() { return "Set 1"; }
	@ConfigItem(keyName="setNameTwo", name="Set 2 name", description="Custom display name", hidden=true)
	default String setNameTwo() { return "Set 2"; }
	@ConfigItem(keyName="setNameThree", name="Set 3 name", description="Custom display name", hidden=true)
	default String setNameThree() { return "Set 3"; }
	@ConfigItem(keyName="setNameFour", name="Set 4 name", description="Custom display name", hidden=true)
	default String setNameFour() { return "Set 4"; }
	@ConfigItem(keyName="setNameFive", name="Set 5 name", description="Custom display name", hidden=true)
	default String setNameFive() { return "Set 5"; }
	@ConfigItem(keyName="setNameSix", name="Set 6 name", description="Custom display name", hidden=true)
	default String setNameSix() { return "Set 6"; }
	@ConfigItem(keyName="setNameSeven", name="Set 7 name", description="Custom display name", hidden=true)
	default String setNameSeven() { return "Set 7"; }
	@ConfigItem(keyName="setNameEight", name="Set 8 name", description="Custom display name", hidden=true)
	default String setNameEight() { return "Set 8"; }
	@ConfigItem(keyName="setNameNine", name="Set 9 name", description="Custom display name", hidden=true)
	default String setNameNine() { return "Set 9"; }
	@ConfigItem(keyName="setNameTen", name="Set 10 name", description="Custom display name", hidden=true)
	default String setNameTen() { return "Set 10"; }
}

