/* Derived from Ganom Custom Swapper (2019-2020), GPL-3.0. */
package com.protolite.ganom.customswapper;
import java.util.*;
final class MacroAction {
    enum Command {EQUIP,CLEAN,REMOVE,PRAYER,CAST,ENABLE}
    final String parameter;final Command command;
    MacroAction(String parameter,Command command){this.parameter=parameter;this.command=command;}
    static List<MacroAction> parse(String source) {
        List<MacroAction> actions=new ArrayList<>();int lineNumber=0;
        for(String line:source.split("\\R")) {
            lineNumber++;line=line.trim();if(line.isEmpty()||line.startsWith("//"))continue;
            int colon=line.lastIndexOf(':');
            if(colon<=0)throw new IllegalArgumentException("Invalid sequence line "+lineNumber+": expected value:command.");
            String parameter=line.substring(0,colon).trim();Command command;
            try{command=Command.valueOf(line.substring(colon+1).trim().toUpperCase(Locale.ROOT));}
            catch(IllegalArgumentException e){throw new IllegalArgumentException("Unknown command on line "+lineNumber+".");}
            if(command==Command.EQUIP||command==Command.REMOVE||command==Command.CLEAN) {
                try{if(Integer.parseInt(parameter)<=0)throw new NumberFormatException();}
                catch(NumberFormatException e){throw new IllegalArgumentException("Expected a positive item ID on line "+lineNumber+".");}
            }
            actions.add(new MacroAction(parameter,command));
        }
        return actions;
    }
}
