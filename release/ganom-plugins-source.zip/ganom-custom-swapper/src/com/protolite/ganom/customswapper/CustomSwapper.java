/* Port of Ganom Custom Swapper (2019-2020), GPL-3.0. */
package com.protolite.ganom.customswapper;

import com.google.inject.Provides;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.Supplier;
import javax.inject.Inject;
import net.runelite.api.Client;
import net.runelite.api.ChatMessageType;
import net.runelite.api.GameState;
import net.runelite.api.InventoryID;
import net.runelite.api.Item;
import net.runelite.api.ItemContainer;
import net.runelite.api.Prayer;
import net.runelite.api.events.CommandExecuted;
import net.runelite.api.events.GameStateChanged;
import net.runelite.api.widgets.Widget;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.config.*;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.input.KeyManager;
import net.runelite.client.plugins.*;
import net.runelite.client.util.*;

@PluginDescriptor(name="<html>[<font color=#F472B6>G</font>] Custom Swapper</html>",
    description="Run explicitly configured hotkey action sequences",tags={"ganom","swap","hotkey"},enabledByDefault=false)
public class CustomSwapper extends Plugin {
    @Inject private Client client;
    @Inject private ClientThread clientThread;
    @Inject private KeyManager keyManager;
    @Inject private CustomSwapperConfig config;
    private final List<HotkeyListener> listeners=new ArrayList<>();
    private final AtomicBoolean busy=new AtomicBoolean();
    private final AtomicInteger generation=new AtomicInteger();
    private volatile boolean active;
    private volatile boolean sendingInput;
    private volatile Future<?> pending;
    private ExecutorService executor;
    private static final String[] SETS={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen","Twenty"};
    enum Tab {
        COMBAT(0,4675),INVENTORY(3,4678),EQUIPMENT(4,4679),PRAYER(5,4680),SPELLBOOK(6,4682);
        final int id,varbit;Tab(int id,int varbit){this.id=id;this.varbit=varbit;}
    }
    @Provides CustomSwapperConfig provideConfig(ConfigManager manager){return manager.getConfig(CustomSwapperConfig.class);}
    @Override protected void startUp() {
        active=true;busy.set(false);
        executor=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"ProtoLite-CustomSwapper");t.setDaemon(true);return t;});
        for(String set:SETS) {
            HotkeyListener listener=new HotkeyListener(()->read("custom"+set,Keybind.class)) {
                @Override public void hotkeyPressed(){submit(read("customSwap"+set,String.class));}
            };
            listeners.add(listener);keyManager.registerKeyListener(listener);
        }
        HotkeyListener stop=new HotkeyListener(()->new Keybind(KeyEvent.VK_ESCAPE,0)) {
            @Override public void hotkeyPressed(){if(!sendingInput)cancel();}
        };
        listeners.add(stop);keyManager.registerKeyListener(stop);
    }
    @Override protected void shutDown() {
        active=false;cancel();
        for(HotkeyListener listener:listeners)keyManager.unregisterKeyListener(listener);
        listeners.clear();if(executor!=null)executor.shutdownNow();
    }
    @Subscribe public void onGameStateChanged(GameStateChanged event){if(event.getGameState()!=GameState.LOGGED_IN)cancel();}
    private <T>T read(String method,Class<T> type) {
        try{return type.cast(CustomSwapperConfig.class.getMethod(method).invoke(config));}
        catch(ReflectiveOperationException e){throw new IllegalStateException("Unable to read macro settings",e);}
    }
    void cancel(){generation.incrementAndGet();Future<?> task=pending;if(task!=null)task.cancel(true);busy.set(false);}
    void submit(String source) {
        if(!active||source==null||source.trim().isEmpty())return;
        final List<MacroAction> actions;
        try{actions=MacroAction.parse(source);}catch(IllegalArgumentException e){report(e.getMessage());return;}
        if(actions.isEmpty()||!busy.compareAndSet(false,true))return;
        final int token=generation.incrementAndGet();
        pending=executor.submit(()->{
            try {
                for(MacroAction action:actions) {
                    check(token);Tab tab=tab(action.command);openTab(tab,token);
                    int repeats=action.command==MacroAction.Command.CLEAN?28:1;
                    for(int i=0;i<repeats;i++) {
                        check(token);
                        Rectangle rectangle=onClient(()->bounds(action));
                        if(rectangle==null) {
                            if(action.command==MacroAction.Command.CLEAN || (action.command==MacroAction.Command.PRAYER && onClient(()->prayerAlreadyActive(action))))break;
                            throw new IllegalStateException("Action target is unavailable or hidden: "+action.command);
                        }
                        click(rectangle,token);pause();
                    }
                }
                if(config.swapBack()){check(token);openTab(Tab.INVENTORY,token);}
            }catch(InterruptedException e){Thread.currentThread().interrupt();}
            catch(Exception e){if(active && generation.get()==token)report(e.getMessage()==null?"Sequence stopped.":e.getMessage());}
            finally{if(generation.get()==token)busy.set(false);}
        });
    }
    static Tab tab(MacroAction.Command command) {
        switch(command){case REMOVE:return Tab.EQUIPMENT;case PRAYER:return Tab.PRAYER;case CAST:return Tab.SPELLBOOK;case ENABLE:return Tab.COMBAT;default:return Tab.INVENTORY;}
    }
    private <T>T onClient(Supplier<T> supplier)throws Exception {
        if(client.isClientThread())return supplier.get();
        CompletableFuture<T> result=new CompletableFuture<>();
        clientThread.invokeLater(()->{try{result.complete(supplier.get());}catch(Throwable e){result.completeExceptionally(e);}});
        return result.get(3,TimeUnit.SECONDS);
    }
    private void check(int token)throws Exception {
        if(!active||generation.get()!=token||Thread.currentThread().isInterrupted())throw new InterruptedException();
        if(!onClient(()->client.getGameState()==GameState.LOGGED_IN && client.getCanvas()!=null && client.getCanvas().isFocusOwner()))
            throw new IllegalStateException("Sequence stopped: RuneLite is not logged in and focused.");
    }
    static int tabKey(int setting){return setting>=1&&setting<=12?111+setting:setting==13?KeyEvent.VK_ESCAPE:0;}
    private void openTab(Tab tab,int token)throws Exception {
        check(token);
        if(onClient(()->client.getVarcIntValue(171)==tab.id))return;
        int key=onClient(()->tabKey(client.getVarbitValue(tab.varbit)));
        if(key==0)throw new IllegalStateException("Set an in-game F-key binding for "+tab+" first.");
        input(token,canvas->{long now=System.currentTimeMillis();canvas.dispatchEvent(new KeyEvent(canvas,KeyEvent.KEY_PRESSED,now,0,key,KeyEvent.CHAR_UNDEFINED));canvas.dispatchEvent(new KeyEvent(canvas,KeyEvent.KEY_RELEASED,now,0,key,KeyEvent.CHAR_UNDEFINED));});
        for(int i=0;i<50;i++){check(token);if(onClient(()->client.getVarcIntValue(171)==tab.id)){pause();return;}Thread.sleep(20);}
        throw new IllegalStateException("Unable to open "+tab+" tab.");
    }
    private void input(int token,java.util.function.Consumer<Canvas> action)throws Exception {
        Canvas canvas=onClient(()->client.getCanvas());
        AtomicBoolean delivered=new AtomicBoolean();
        EventQueue.invokeAndWait(()->{if(active&&generation.get()==token&&canvas.isFocusOwner()){sendingInput=true;try{action.accept(canvas);delivered.set(true);}finally{sendingInput=false;}}});
        if(!delivered.get())throw new InterruptedException();
    }
    private void click(Rectangle rectangle,int token)throws Exception {
        Point point=new Point(rectangle.x+rectangle.width/2,rectangle.y+rectangle.height/2);
        point=onClient(()->screenPoint(rectangle,client.isStretchedEnabled(),client.getRealDimensions(),client.getStretchedDimensions()));
        final Point target=point;
        input(token,canvas->{long now=System.currentTimeMillis();for(int id:new int[]{MouseEvent.MOUSE_PRESSED,MouseEvent.MOUSE_RELEASED,MouseEvent.MOUSE_CLICKED})canvas.dispatchEvent(new MouseEvent(canvas,id,now,0,target.x,target.y,1,false,MouseEvent.BUTTON1));});
    }
    static Point screenPoint(Rectangle rectangle,boolean stretched,Dimension real,Dimension display) {
        int x=rectangle.x+rectangle.width/2,y=rectangle.y+rectangle.height/2;
        if(stretched && real.width>0 && real.height>0){x=(int)(x*display.getWidth()/real.width);y=(int)(y*display.getHeight()/real.height);}
        return new Point(x,y);
    }
    private void pause()throws InterruptedException {int low=Math.max(0,Math.min(5000,config.randLow())),high=Math.max(low,Math.min(5000,config.randHigh()));Thread.sleep(ThreadLocalRandom.current().nextInt(low,high+1));}
    Rectangle bounds(MacroAction action) {
        if(prayerAlreadyActive(action))return null;
        Widget root;Widget target;
        switch(action.command) {
            case EQUIP:case CLEAN:root=client.getWidget(149,0);target=find(root,w->w.getItemId()==Integer.parseInt(action.parameter));break;
            case REMOVE:root=client.getWidget(387,0);target=find(root,w->w.getItemId()==Integer.parseInt(action.parameter));break;
            case ENABLE:target=client.getWidget(593,39);break;
            default:
                int group=action.command==MacroAction.Command.PRAYER?541:218;
                target=numericWidget(action.parameter);
                if(target==null)target=find(client.getWidget(group,0),w->matchesName(w,action.parameter));
        }
        if(target==null||target.isHidden()||target.getBounds()==null||target.getBounds().width<=0||target.getBounds().height<=0)return null;
        return new Rectangle(target.getBounds());
    }
    boolean prayerAlreadyActive(MacroAction action) {
        if(action.command!=MacroAction.Command.PRAYER || !config.enablePrayCheck())return false;
        try{return client.isPrayerActive(Prayer.valueOf(action.parameter.toUpperCase(Locale.ROOT).replace(' ','_')));}catch(IllegalArgumentException e){return false;}
    }
    private Widget numericWidget(String parameter) {
        try{String[] ids=parameter.split(":");if(ids.length==2)return client.getWidget(Integer.parseInt(ids[0]),Integer.parseInt(ids[1]));if(parameter.matches("\\d+"))return client.getWidget(Integer.parseInt(parameter));}catch(NumberFormatException ignored){}return null;
    }
    static String normalize(String text){return text==null?"":Text.removeTags(text).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");}
    static boolean matchesName(Widget widget,String parameter){String name=normalize(parameter);return !name.isEmpty()&&(normalize(widget.getName()).equals(name)||normalize(widget.getText()).equals(name));}
    static Widget find(Widget root,java.util.function.Predicate<Widget> predicate) {
        if(root==null)return null;Set<Widget> seen=Collections.newSetFromMap(new IdentityHashMap<>());Deque<Widget> pending=new ArrayDeque<>();pending.add(root);
        while(!pending.isEmpty()) {Widget widget=pending.removeFirst();if(!seen.add(widget))continue;if(!widget.isHidden()&&predicate.test(widget))return widget;
            for(Widget[] children:new Widget[][]{widget.getChildren(),widget.getStaticChildren(),widget.getDynamicChildren(),widget.getNestedChildren()})if(children!=null)for(Widget child:children)if(child!=null)pending.add(child);
        }return null;
    }
    private void report(String message){clientThread.invokeLater(()->client.addChatMessage(ChatMessageType.GAMEMESSAGE,"","[G Custom Swapper] "+message,null));}
    @Subscribe public void onCommandExecuted(CommandExecuted event) {
        if(!event.getCommand().equalsIgnoreCase("copycs"))return;
        ItemContainer items=client.getItemContainer(InventoryID.EQUIPMENT);if(items==null)return;
        StringBuilder text=new StringBuilder();for(Item item:items.getItems())if(item!=null&&item.getId()>0)text.append(item.getId()).append(":equip\n");
        String copied=text.toString();EventQueue.invokeLater(()->Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(copied),null));
    }
}

