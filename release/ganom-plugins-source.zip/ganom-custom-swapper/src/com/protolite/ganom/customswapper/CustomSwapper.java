/* Port of Ganom Custom Swapper (2019-2020), GPL-3.0. */
package com.protolite.ganom.customswapper;

import com.google.inject.Provides;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.Supplier;
import javax.inject.Inject;
import net.runelite.api.Client;
import net.runelite.api.ChatMessageType;
import net.runelite.api.GameState;
import net.runelite.api.InventoryID;
import net.runelite.api.Item;
import net.runelite.api.ItemContainer;
import net.runelite.api.Prayer;
import net.runelite.api.events.CommandExecuted;
import net.runelite.api.events.GameStateChanged;
import net.runelite.api.widgets.Widget;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.config.*;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.input.KeyManager;
import net.runelite.client.game.ItemManager;
import net.runelite.client.plugins.*;
import net.runelite.client.util.*;

@PluginDescriptor(name="<html>[<font color=#F472B6>G</font>] Custom Swapper</html>",
    description="Run explicitly configured hotkey action sequences",tags={"ganom","swap","hotkey"},enabledByDefault=false)
public class CustomSwapper extends Plugin {
    @Inject private Client client;
    @Inject private ItemManager itemManager;
    @Inject private ClientThread clientThread;
    @Inject private KeyManager keyManager;
    @Inject private CustomSwapperConfig config;
    @Inject private ConfigManager configManager;
    private SwapperSettingsControls settingsControls;
    private final List<HotkeyListener> listeners=new ArrayList<>();
    private final AtomicBoolean busy=new AtomicBoolean();
    private final AtomicInteger generation=new AtomicInteger();
    private volatile boolean active;
    private volatile boolean sendingInput;
    private volatile long sequenceDeadline;
    private volatile Future<?> pending;
    private ScheduledExecutorService executor;
    static final String[] SETS={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"};
    enum Tab {
        COMBAT(0,4675),INVENTORY(3,4678),EQUIPMENT(4,4679),PRAYER(5,4680),SPELLBOOK(6,4682);
        final int id,varbit;Tab(int id,int varbit){this.id=id;this.varbit=varbit;}
    }
    @Provides CustomSwapperConfig provideConfig(ConfigManager manager){return manager.getConfig(CustomSwapperConfig.class);}
    @Override protected void startUp() {
        active=true;busy.set(false);
        executor=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"ProtoLite-CustomSwapper");t.setDaemon(true);return t;});
        for(String set:SETS) {
            HotkeyListener listener=new HotkeyListener(()->read("custom"+set,Keybind.class)) {
                private boolean held;
                private int heldKey;
                @Override public void hotkeyPressed(){
                    if(sendingInput||held)return;
                    held=true;heldKey=read("custom"+set,Keybind.class).getKeyCode();
                    submit(read("customSwap"+set,String.class));
                }
                @Override public void keyPressed(KeyEvent event){if(!sendingInput)super.keyPressed(event);}
                @Override public void keyReleased(KeyEvent event){if(sendingInput)return;super.keyReleased(event);if(event.getKeyCode()==heldKey){held=false;super.focusLost();}}
                @Override public void focusLost(){super.focusLost();held=false;}
            };
            listeners.add(listener);keyManager.registerKeyListener(listener);
        }
        if(configManager!=null){settingsControls=new SwapperSettingsControls(this::copyWornGear,this::setName,(index,name)->configManager.setConfiguration("customSwapper","setName"+SETS[index],name));settingsControls.start();}
    }
    @Override protected void shutDown() {
        active=false;cancel();
        if(settingsControls!=null){settingsControls.stop();settingsControls=null;}
        for(HotkeyListener listener:listeners)keyManager.unregisterKeyListener(listener);
        listeners.clear();if(executor!=null)executor.shutdownNow();
    }
    @Subscribe public void onGameStateChanged(GameStateChanged event){if(event.getGameState()!=GameState.LOGGED_IN)cancel();}
    private <T>T read(String method,Class<T> type) {
        try{return type.cast(CustomSwapperConfig.class.getMethod(method).invoke(config));}
        catch(ReflectiveOperationException e){throw new IllegalStateException("Unable to read macro settings",e);}
    }
    void cancel(){generation.incrementAndGet();Future<?> task=pending;if(task!=null)task.cancel(true);busy.set(false);}
    void submit(String source) {
        if(!active||source==null||source.trim().isEmpty())return;
        final List<MacroAction> actions;
        try{actions=MacroAction.parse(source);}catch(IllegalArgumentException e){report(e.getMessage());return;}
        if(actions.isEmpty())return;
        if(!busy.compareAndSet(false,true)){report("A swap is already running.");return;}
        final int token=generation.incrementAndGet();
        final long started=System.nanoTime();
        pending=executor.submit(()->{
            try {
                sequenceDeadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(60);
                EquipmentPlan plan=onClient(()->equipmentPlan(actions));
                int clicks=0,skipped=0;
                for(MacroAction action:actions) {
                    int repeats=action.command==MacroAction.Command.CLEAN?28:1;
                    for(int i=0;i<repeats;i++) {
                        checkToken(token);
                        PreparedAction prepared=onClient(()->prepareAction(action,token));
                        if(prepared.needsTab){openTab(tab(action.command),token);prepared=onClient(()->prepareAction(action,token));}
                        if(prepared.skipped){skipped++;break;}
                        if(prepared.target==null){
                            if(action.command==MacroAction.Command.CLEAN)break;
                            throw new IllegalStateException("Action target is unavailable or hidden: "+action.parameter+":"+action.command.name().toLowerCase(Locale.ROOT));
                        }
                        click(prepared,token);clicks++;pause();
                    }
                }
                if(config.reportTiming())report("Sent "+clicks+" clicks in "+TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started)+" ms; skipped "+skipped+" satisfied actions. Equipment check follows separately.");
                if(config.swapBack()){check(token);openTab(Tab.INVENTORY,token);}
                if(!plan.isEmpty())executor.schedule(()->verifyEquipment(plan,token),1500,TimeUnit.MILLISECONDS);
            }catch(InterruptedException e){Thread.currentThread().interrupt();}
            catch(Exception e){if(active && generation.get()==token)report(e.getMessage()==null?"Sequence stopped.":e.getMessage());}
            finally{if(generation.get()==token)busy.set(false);}
        });
    }
    static Tab tab(MacroAction.Command command) {
        switch(command){case REMOVE:return Tab.EQUIPMENT;case PRAYER:return Tab.PRAYER;case CAST:return Tab.SPELLBOOK;case ENABLE:return Tab.COMBAT;default:return Tab.INVENTORY;}
    }
    private <T>T onClient(Supplier<T> supplier)throws Exception {
        if(client.isClientThread())return supplier.get();
        CompletableFuture<T> result=new CompletableFuture<>();
        clientThread.invokeLater(()->{try{result.complete(supplier.get());}catch(Throwable e){result.completeExceptionally(e);}});
        return result.get(3,TimeUnit.SECONDS);
    }
    private void checkToken(int token)throws InterruptedException {
        if(!active||generation.get()!=token||Thread.currentThread().isInterrupted())throw new InterruptedException();
        if(sequenceDeadline!=0&&System.nanoTime()-sequenceDeadline>=0)throw new IllegalStateException("Sequence stopped: 60-second time limit reached.");
    }
    private void check(int token)throws Exception {
        checkToken(token);
        if(!onClient(()->client.getGameState()==GameState.LOGGED_IN && client.getCanvas()!=null && client.getCanvas().isFocusOwner()))
            throw new IllegalStateException("Sequence stopped: RuneLite is not logged in and focused.");
    }
    static int tabKey(int setting){return setting>=1&&setting<=12?111+setting:setting==13?KeyEvent.VK_ESCAPE:0;}
    private void openTab(Tab tab,int token)throws Exception {
        check(token);
        if(onClient(()->client.getVarcIntValue(171)==tab.id))return;
        int key=onClient(()->tabKey(client.getVarbitValue(tab.varbit)));
        if(key==0)throw new IllegalStateException("Set an in-game F-key binding for "+tab+" first.");
        input(token,canvas->{long now=System.currentTimeMillis();canvas.dispatchEvent(new KeyEvent(canvas,KeyEvent.KEY_PRESSED,now,0,key,KeyEvent.CHAR_UNDEFINED));canvas.dispatchEvent(new KeyEvent(canvas,KeyEvent.KEY_RELEASED,now,0,key,KeyEvent.CHAR_UNDEFINED));});
        for(int i=0;i<50;i++){check(token);if(onClient(()->client.getVarcIntValue(171)==tab.id)){pause();return;}Thread.sleep(20);}
        throw new IllegalStateException("Unable to open "+tab+" tab.");
    }
    private void input(int token,java.util.function.Consumer<Canvas> action)throws Exception {
        Canvas canvas=onClient(()->client.getCanvas());
        input(token,canvas,action);
    }
    private void input(int token,Canvas canvas,java.util.function.Consumer<Canvas> action)throws Exception {
        checkToken(token);
        AtomicBoolean delivered=new AtomicBoolean();
        EventQueue.invokeAndWait(()->{if(active&&generation.get()==token&&canvas.isFocusOwner()){sendingInput=true;try{action.accept(canvas);delivered.set(true);}finally{sendingInput=false;}}});
        if(!delivered.get())throw new InterruptedException();
    }
    static final class PreparedAction {
        final Canvas canvas;final Point target;final boolean skipped,needsTab;
        PreparedAction(Canvas canvas,Point target,boolean skipped,boolean needsTab){this.canvas=canvas;this.target=target;this.skipped=skipped;this.needsTab=needsTab;}
    }
    PreparedAction prepareAction(MacroAction action,int token){
        if(!active||generation.get()!=token)throw new CancellationException();
        Canvas canvas=client.getCanvas();
        if(client.getGameState()!=GameState.LOGGED_IN||canvas==null||!canvas.isFocusOwner())throw new IllegalStateException("Sequence stopped: RuneLite is not logged in and focused.");
        if(actionAlreadySatisfied(action))return new PreparedAction(canvas,null,true,false);
        if(client.getVarcIntValue(171)!=tab(action.command).id)return new PreparedAction(canvas,null,false,true);
        Rectangle rectangle=bounds(action);
        Point point=rectangle==null?null:screenPoint(rectangle,client.isStretchedEnabled(),client.getRealDimensions(),client.getStretchedDimensions());
        return new PreparedAction(canvas,point,false,false);
    }
    void click(PreparedAction prepared,int token)throws Exception {
        final Point target=prepared.target;
        input(token,prepared.canvas,canvas->{long now=System.currentTimeMillis();for(int id:new int[]{MouseEvent.MOUSE_PRESSED,MouseEvent.MOUSE_RELEASED,MouseEvent.MOUSE_CLICKED})canvas.dispatchEvent(new MouseEvent(canvas,id,now,0,target.x,target.y,1,false,MouseEvent.BUTTON1));});
    }
    static Point screenPoint(Rectangle rectangle,boolean stretched,Dimension real,Dimension display) {
        int x=rectangle.x+rectangle.width/2,y=rectangle.y+rectangle.height/2;
        if(stretched && real.width>0 && real.height>0){x=(int)(x*display.getWidth()/real.width);y=(int)(y*display.getHeight()/real.height);}
        return new Point(x,y);
    }
    private void pause()throws InterruptedException {int low=Math.max(0,Math.min(5000,config.randLow())),high=Math.max(low,Math.min(5000,config.randHigh()));Thread.sleep(ThreadLocalRandom.current().nextInt(low,high+1));}
    Rectangle bounds(MacroAction action) {
        if(actionAlreadySatisfied(action))return null;
        Widget root;Widget target;
        switch(action.command) {
            case EQUIP:case CLEAN:root=client.getWidget(149,0);target=find(root,w->w.getItemId()==Integer.parseInt(action.parameter));break;
            case REMOVE:root=client.getWidget(387,0);target=find(root,w->w.getItemId()==Integer.parseInt(action.parameter));break;
            case ENABLE:target=client.getWidget(593,39);break;
            default:
                int group=action.command==MacroAction.Command.PRAYER?541:218;
                target=numericWidget(action.parameter);
                if(target==null)target=find(client.getWidget(group,0),w->matchesName(w,action.parameter));
        }
        if(target==null||target.isHidden()||target.getBounds()==null||target.getBounds().width<=0||target.getBounds().height<=0)return null;
        return new Rectangle(target.getBounds());
    }
    boolean actionAlreadySatisfied(MacroAction action) {
        if(prayerAlreadyActive(action))return true;
        if(action.command!=MacroAction.Command.EQUIP&&action.command!=MacroAction.Command.REMOVE)return false;
        ItemContainer worn=client.getItemContainer(InventoryID.EQUIPMENT);if(worn==null)return false;
        int id=Integer.parseInt(action.parameter);boolean equipped=false;
        for(Item item:worn.getItems())if(item!=null&&item.getId()==id&&item.getQuantity()>0){equipped=true;break;}
        return action.command==MacroAction.Command.EQUIP?equipped:!equipped;
    }
    EquipmentPlan equipmentPlan(List<MacroAction> actions){
        EquipmentPlan plan=new EquipmentPlan();if(itemManager==null)return plan;
        for(MacroAction action:actions){
            if(action.command!=MacroAction.Command.EQUIP&&action.command!=MacroAction.Command.REMOVE)continue;
            int id=Integer.parseInt(action.parameter);
            net.runelite.http.api.item.ItemStats stats=itemManager.getItemStats(id,false);
            if(stats==null||stats.getEquipment()==null)continue;
            net.runelite.http.api.item.ItemEquipmentStats gear=stats.getEquipment();
            if(action.command==MacroAction.Command.EQUIP)plan.equip(gear.getSlot(),id,gear.isTwoHanded());
            else plan.remove(gear.getSlot(),id);
        }
        return plan;
    }
    void verifyEquipment(EquipmentPlan plan,int token){
        try{
            if(!active||generation.get()!=token)return;
            List<String> missing=onClient(()->{
                if(!active||generation.get()!=token||client.getGameState()!=GameState.LOGGED_IN)return Collections.emptyList();
                ItemContainer worn=client.getItemContainer(InventoryID.EQUIPMENT);if(worn==null)return Collections.emptyList();
                Item[] items=worn.getItems();return plan.missing(slot->slot>=0&&slot<items.length&&items[slot]!=null&&items[slot].getQuantity()>0?items[slot].getId():-1);
            });
            if(active&&generation.get()==token&&!missing.isEmpty())report("Equipment check: "+String.join(", ",missing)+" not confirmed. No automatic retry.");
        }catch(Exception ignored){/* A stale or unavailable client never blocks a new hotkey. */}
    }
    boolean prayerAlreadyActive(MacroAction action) {
        if(action.command!=MacroAction.Command.PRAYER || !config.enablePrayCheck())return false;
        try{return client.isPrayerActive(Prayer.valueOf(action.parameter.toUpperCase(Locale.ROOT).replace(' ','_')));}catch(IllegalArgumentException e){return false;}
    }
    private Widget numericWidget(String parameter) {
        try{String[] ids=parameter.split(":");if(ids.length==2)return client.getWidget(Integer.parseInt(ids[0]),Integer.parseInt(ids[1]));if(parameter.matches("\\d+"))return client.getWidget(Integer.parseInt(parameter));}catch(NumberFormatException ignored){}return null;
    }
    static String normalize(String text){return text==null?"":Text.removeTags(text).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");}
    static boolean matchesName(Widget widget,String parameter){String name=normalize(parameter);return !name.isEmpty()&&(normalize(widget.getName()).equals(name)||normalize(widget.getText()).equals(name));}
    static Widget find(Widget root,java.util.function.Predicate<Widget> predicate) {
        if(root==null)return null;Set<Widget> seen=Collections.newSetFromMap(new IdentityHashMap<>());Deque<Widget> pending=new ArrayDeque<>();pending.add(root);
        while(!pending.isEmpty()) {Widget widget=pending.removeFirst();if(!seen.add(widget))continue;if(!widget.isHidden()&&predicate.test(widget))return widget;
            for(Widget[] children:new Widget[][]{widget.getChildren(),widget.getStaticChildren(),widget.getDynamicChildren(),widget.getNestedChildren()})if(children!=null)for(Widget child:children)if(child!=null)pending.add(child);
        }return null;
    }
    private void report(String message){
        if(config!=null&&!config.chatMessages())return;
        clientThread.invokeLater(()->{if(config==null||config.chatMessages())client.addChatMessage(ChatMessageType.GAMEMESSAGE,"","[G Custom Swapper] "+message,null);});
    }
    private String setName(int index){String value=configManager.getConfiguration("customSwapper","setName"+SETS[index]);return value==null||value.trim().isEmpty()?"Set "+(index+1):value.trim();}
    private void copyWornGear(){
        clientThread.invokeLater(()->{
            if(client.getGameState()!=GameState.LOGGED_IN){report("Log in before copying worn gear.");return;}
            ItemContainer equipment=client.getItemContainer(InventoryID.EQUIPMENT);
            String copied=EquipmentExport.format(equipment==null?null:equipment.getItems());
            if(copied.isEmpty()){report("No worn gear to copy. Clipboard unchanged.");return;}
            EventQueue.invokeLater(()->{try{Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(copied),null);report("Worn gear copied. Paste into a swap entry (ID:equip per line).");}catch(IllegalStateException error){report("Clipboard is busy. Try Copy worn gear again.");}});
        });
    }
    @Subscribe public void onCommandExecuted(CommandExecuted event) {
        if(!event.getCommand().equalsIgnoreCase("copycs"))return;
        copyWornGear();
    }
}

