package com.protolite.ganom.customswapper;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.lang.reflect.*;
import java.util.*;
import javax.swing.*;
import net.runelite.api.Item;
import net.runelite.client.config.*;
public class SettingsCheck {
 static void check(boolean result,String message){if(!result)throw new AssertionError(message);}
 static Object get(Object object,String name)throws Exception{Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
 static JButton button(Container root,String name){for(Component child:root.getComponents()){if(child instanceof JButton&&((JButton)child).getText().equals(name))return (JButton)child;if(child instanceof Container){JButton found=button((Container)child,name);if(found!=null)return found;}}return null;}
 static void layout(Container root){root.doLayout();for(Component child:root.getComponents())if(child instanceof Container)layout((Container)child);}
 public static void main(String[] args)throws Exception{
  long swaps=Arrays.stream(CustomSwapperConfig.class.getMethods()).filter(m->m.getName().startsWith("customSwap")).count();check(swaps==10,"Exactly ten swap entries");check(CustomSwapper.SETS.length==10,"Exactly ten registered sets");
  String exported=EquipmentExport.format(new Item[]{new Item(11802,1),null,new Item(-1,0),new Item(0,0),new Item(11212,75),new Item(999,0)});
  check(exported.equals("11802:equip\n11212:equip"),"Exact paste-ready syntax, empty slots omitted");var actions=MacroAction.parse(exported);check(actions.size()==2&&actions.stream().allMatch(a->a.command==MacroAction.Command.EQUIP),"Export round-trips through actual parser");check(EquipmentExport.format(null).isEmpty(),"Missing equipment");
  SwingUtilities.invokeAndWait(()->{try{
   Class<?> panelType=Class.forName("net.runelite.client.plugins.config.ConfigPanel");Constructor<?> constructor=panelType.getDeclaredConstructors()[0];constructor.setAccessible(true);Container nativePanel=(Container)constructor.newInstance(new Object[constructor.getParameterCount()]);
   var config=(CustomSwapperConfig)Proxy.newProxyInstance(CustomSwapperConfig.class.getClassLoader(),new Class[]{CustomSwapperConfig.class},(p,m,a)->m.getReturnType()==String.class?"":null);
   ConfigDescriptor configDescriptor=new ConfigDescriptor(CustomSwapperConfig.class.getAnnotation(ConfigGroup.class),Collections.emptyList(),Collections.emptyList());Class<?> descriptorType=Class.forName("net.runelite.client.plugins.config.PluginConfigurationDescriptor");Object descriptor=null;
   for(Constructor<?> c:descriptorType.getDeclaredConstructors())if(c.getParameterCount()==5){c.setAccessible(true);descriptor=c.newInstance("Custom Swapper","",new String[0],config,configDescriptor);}
   Field field=panelType.getDeclaredField("pluginConfig");field.setAccessible(true);field.set(nativePanel,descriptor);
   JPanel main=(JPanel)get(nativePanel,"mainPanel");JLabel swap=new JLabel("Swap Set: One"),key=new JLabel("Execute One");main.add(swap);main.add(key);main.add(new JLabel());
   Map<Integer,String> names=new HashMap<>();int[] copies={0};SwapperSettingsControls controls=new SwapperSettingsControls(()->copies[0]++,i->names.getOrDefault(i,"Set "+(i+1)),names::put);
   Method visit=SwapperSettingsControls.class.getDeclaredMethod("visit",Container.class);visit.setAccessible(true);visit.invoke(controls,nativePanel);
   check(button(main,"Copy worn gear")!=null&&button(main,"Rename sets...")!=null,"Buttons mounted in real RuneLite settings panel");int count=main.getComponentCount();visit.invoke(controls,nativePanel);check(main.getComponentCount()==count,"No duplicate controls");button(main,"Copy worn gear").doClick();check(copies[0]==1,"Copy button callback");
   String[] updated=new String[10];Arrays.fill(updated,"");updated[0]="  Mage gear  ";controls.saveNames(updated);controls.enhance(main);check(swap.getText().equals("Swap: Mage gear")&&key.getText().equals("Execute Mage gear"),"Saved names update both labels");check(names.get(1).equals("Set 2"),"Blank names fall back safely");
   if(args.length>0){nativePanel.setSize(225,420);layout(nativePanel);BufferedImage image=new BufferedImage(225,420,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();nativePanel.printAll(g);g.dispose();javax.imageio.ImageIO.write(image,"png",new java.io.File(args[0],"custom-swapper-settings.png"));}
   controls.stop();
  }catch(Exception error){throw new RuntimeException(error);}});
  SwingUtilities.invokeAndWait(()->{});
  System.out.println("PASS: 10 sets, native settings controls, no duplicate buttons, copy callback, equipment export/parser round-trip, persisted names and matching swap/hotkey labels. Clipboard untouched.");
 }
}
