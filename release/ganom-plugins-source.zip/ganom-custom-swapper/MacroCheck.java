package com.protolite.ganom.customswapper;
import java.awt.*;
import java.lang.reflect.*;
import java.util.*;
import net.runelite.api.*;
import net.runelite.api.widgets.Widget;
import net.runelite.client.input.KeyManager;
import net.runelite.client.eventbus.EventBus;
public class MacroCheck {
 static <T>T mock(Class<T> c,java.util.function.BiFunction<String,Object[],Object> fn){return c.cast(Proxy.newProxyInstance(c.getClassLoader(),new Class[]{c},(p,m,a)->{Object v=fn.apply(m.getName(),a);if(v!=null)return v;if(m.getReturnType()==boolean.class)return false;if(m.getReturnType()==int.class)return 0;return null;}));}
 static void set(Object o,String name,Object value)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);f.set(o,value);}
 public static void main(String[]args)throws Exception {
  var actions=MacroAction.parse("// note\n123:equip\n123:remove\n123:equip\n218:47:cast\nprotect from magic:prayer\nspecial:enable");
  if(actions.size()!=6||!actions.get(3).parameter.equals("218:47")||actions.get(1).command!=MacroAction.Command.REMOVE)throw new AssertionError("sequence order");
  for(String invalid:new String[]{"bad","12:unknown","-1:equip","abc:clean"}){try{MacroAction.parse(invalid);throw new AssertionError("invalid accepted");}catch(IllegalArgumentException expected){}}
  if(CustomSwapper.tabKey(1)!=112||CustomSwapper.tabKey(12)!=123||CustomSwapper.tabKey(13)!=27||CustomSwapper.tabKey(0)!=0)throw new AssertionError("tab mapping");
  if(!CustomSwapper.screenPoint(new Rectangle(10,20,20,20),true,new Dimension(100,100),new Dimension(200,200)).equals(new java.awt.Point(40,60)))throw new AssertionError("stretched coordinates");
  Widget leaf=mock(Widget.class,(n,a)->n.equals("getItemId")?123:null);
  Widget root=mock(Widget.class,(n,a)->n.equals("getDynamicChildren")?new Widget[]{leaf}:null);
  if(CustomSwapper.find(root,w->w.getItemId()==123)!=leaf)throw new AssertionError("widget traversal");
  ItemContainer worn=mock(ItemContainer.class,(n,a)->n.equals("getItems")?new Item[]{new Item(11802,1),new Item(-1,0)}:null);
  Client gearClient=mock(Client.class,(n,a)->n.equals("getItemContainer")?worn:null);CustomSwapper gearPlugin=new CustomSwapper();set(gearPlugin,"client",gearClient);
  if(!gearPlugin.actionAlreadySatisfied(MacroAction.parse("11802:equip").get(0)))throw new AssertionError("already-worn gear must be skipped");
  if(gearPlugin.actionAlreadySatisfied(MacroAction.parse("123:equip").get(0)))throw new AssertionError("missing gear must still be equipped");
  if(gearPlugin.actionAlreadySatisfied(MacroAction.parse("11802:remove").get(0)))throw new AssertionError("remove action must not be skipped");
  if(gearPlugin.bounds(MacroAction.parse("11802:equip").get(0))!=null)throw new AssertionError("already-worn gear should not create a click target");
  Client client=mock(Client.class,(n,a)->{throw new AssertionError("Enable must not access game inputs: "+n);});
  var constructor=KeyManager.class.getDeclaredConstructor(Client.class,EventBus.class);constructor.setAccessible(true);
  KeyManager manager=constructor.newInstance(client,new EventBus());
  CustomSwapper plugin=new CustomSwapper();set(plugin,"keyManager",manager);plugin.startUp();
  Field listeners=KeyManager.class.getDeclaredField("keyListeners");listeners.setAccessible(true);
  if(((java.util.List<?>)listeners.get(manager)).size()!=11)throw new AssertionError("10 hotkeys plus stop");
  Field task=CustomSwapper.class.getDeclaredField("pending");task.setAccessible(true);if(task.get(plugin)!=null)throw new AssertionError("enable executed sequence");
  var stop=(net.runelite.client.input.KeyListener)((java.util.List<?>)listeners.get(manager)).get(10);
  var busyField=CustomSwapper.class.getDeclaredField("busy");busyField.setAccessible(true);var busy=(java.util.concurrent.atomic.AtomicBoolean)busyField.get(plugin);
  var generationField=CustomSwapper.class.getDeclaredField("generation");generationField.setAccessible(true);var generation=(java.util.concurrent.atomic.AtomicInteger)generationField.get(plugin);
  Canvas canvas=new Canvas();int original=generation.get();
  var idleEscape=new java.awt.event.KeyEvent(canvas,java.awt.event.KeyEvent.KEY_PRESSED,0,0,java.awt.event.KeyEvent.VK_ESCAPE,java.awt.event.KeyEvent.CHAR_UNDEFINED);stop.keyPressed(idleEscape);
  if(idleEscape.isConsumed()||generation.get()!=original)throw new AssertionError("idle Escape must pass through");
  busy.set(true);set(plugin,"sendingInput",true);stop.keyPressed(idleEscape);if(!busy.get()||generation.get()!=original)throw new AssertionError("synthetic tab Escape must not cancel");set(plugin,"sendingInput",false);
  var runningEscape=new java.awt.event.KeyEvent(canvas,java.awt.event.KeyEvent.KEY_PRESSED,0,0,java.awt.event.KeyEvent.VK_ESCAPE,java.awt.event.KeyEvent.CHAR_UNDEFINED);stop.keyPressed(runningEscape);
  if(runningEscape.isConsumed()||busy.get()||generation.get()!=original+1)throw new AssertionError("running Escape must cancel and pass through");
  var release=new java.awt.event.KeyEvent(canvas,java.awt.event.KeyEvent.KEY_RELEASED,0,0,java.awt.event.KeyEvent.VK_ESCAPE,java.awt.event.KeyEvent.CHAR_UNDEFINED);stop.keyReleased(release);
  var typed=new java.awt.event.KeyEvent(canvas,java.awt.event.KeyEvent.KEY_TYPED,0,0,java.awt.event.KeyEvent.VK_UNDEFINED,(char)27);stop.keyTyped(typed);if(release.isConsumed()||typed.isConsumed())throw new AssertionError("Escape release and typed events must pass through");
  plugin.submit("");plugin.cancel();plugin.shutDown();if(!((java.util.List<?>)listeners.get(manager)).isEmpty())throw new AssertionError("listeners leaked");
  java.util.List<String> messages=new java.util.concurrent.CopyOnWriteArrayList<>();Canvas focused=new Canvas(){@Override public boolean isFocusOwner(){return true;}};
  Client engineClient=mock(Client.class,(n,a)->{switch(n){case "getGameState":return GameState.LOGGED_IN;case "isClientThread":return true;case "getCanvas":return focused;case "getVarcIntValue":return 3;case "getItemContainer":return worn;case "addChatMessage":messages.add((String)a[2]);return null;default:return null;}});
  CustomSwapper engine=new CustomSwapper();set(engine,"client",engineClient);set(engine,"keyManager",manager);set(engine,"clientThread",new net.runelite.client.callback.ClientThread(){@Override public void invokeLater(Runnable action){action.run();}});engine.startUp();engine.submit("11802:equip\n123:equip");
  ((java.util.concurrent.Future<?>)task.get(engine)).get(2,java.util.concurrent.TimeUnit.SECONDS);engine.shutDown();
  if(messages.stream().noneMatch(s->s.contains("123:equip")))throw new AssertionError("sequence must advance past worn gear to the next item");
  System.out.println("PASS: parser, tab mapping, scaling, widget traversal, ten hotkeys, Escape pass-through while idle/running, synthetic-Escape guard, cancellation and cleanup. No mouse or keyboard events dispatched.");
 }
}

