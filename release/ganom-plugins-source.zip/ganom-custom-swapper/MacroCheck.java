package com.protolite.ganom.customswapper;
import java.awt.*;
import java.lang.reflect.*;
import java.util.*;
import net.runelite.api.*;
import net.runelite.api.widgets.Widget;
import net.runelite.client.input.KeyManager;
import net.runelite.client.eventbus.EventBus;
public class MacroCheck {
 static <T>T mock(Class<T> c,java.util.function.BiFunction<String,Object[],Object> fn){return c.cast(Proxy.newProxyInstance(c.getClassLoader(),new Class[]{c},(p,m,a)->{Object v=fn.apply(m.getName(),a);if(v!=null)return v;if(m.getReturnType()==boolean.class)return false;if(m.getReturnType()==int.class)return 0;return null;}));}
 static void set(Object o,String name,Object value)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);f.set(o,value);}
 public static void main(String[]args)throws Exception {
  var actions=MacroAction.parse("// note\n123:equip\n123:remove\n123:equip\n218:47:cast\nprotect from magic:prayer\nspecial:enable");
  if(actions.size()!=6||!actions.get(3).parameter.equals("218:47")||actions.get(1).command!=MacroAction.Command.REMOVE)throw new AssertionError("sequence order");
  for(String invalid:new String[]{"bad","12:unknown","-1:equip","abc:clean"}){try{MacroAction.parse(invalid);throw new AssertionError("invalid accepted");}catch(IllegalArgumentException expected){}}
  if(CustomSwapper.tabKey(1)!=112||CustomSwapper.tabKey(12)!=123||CustomSwapper.tabKey(13)!=27||CustomSwapper.tabKey(0)!=0)throw new AssertionError("tab mapping");
  if(!CustomSwapper.screenPoint(new Rectangle(10,20,20,20),true,new Dimension(100,100),new Dimension(200,200)).equals(new java.awt.Point(40,60)))throw new AssertionError("stretched coordinates");
  Widget leaf=mock(Widget.class,(n,a)->n.equals("getItemId")?123:null);
  Widget root=mock(Widget.class,(n,a)->n.equals("getDynamicChildren")?new Widget[]{leaf}:null);
  if(CustomSwapper.find(root,w->w.getItemId()==123)!=leaf)throw new AssertionError("widget traversal");
  Client client=mock(Client.class,(n,a)->{throw new AssertionError("Enable must not access game inputs: "+n);});
  var constructor=KeyManager.class.getDeclaredConstructor(Client.class,EventBus.class);constructor.setAccessible(true);
  KeyManager manager=constructor.newInstance(client,new EventBus());
  CustomSwapper plugin=new CustomSwapper();set(plugin,"keyManager",manager);plugin.startUp();
  Field listeners=KeyManager.class.getDeclaredField("keyListeners");listeners.setAccessible(true);
  if(((java.util.List<?>)listeners.get(manager)).size()!=11)throw new AssertionError("10 hotkeys plus stop");
  Field task=CustomSwapper.class.getDeclaredField("pending");task.setAccessible(true);if(task.get(plugin)!=null)throw new AssertionError("enable executed sequence");
  plugin.submit("");plugin.cancel();plugin.shutDown();if(!((java.util.List<?>)listeners.get(manager)).isEmpty())throw new AssertionError("listeners leaked");
  System.out.println("PASS: parser order/repeated steps, invalid commands, tab bindings, scaling, widget traversal, 10 idle hotkeys, cancellation and cleanup. No mouse or keyboard events dispatched.");
 }
}

