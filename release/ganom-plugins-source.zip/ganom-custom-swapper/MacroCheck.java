package com.protolite.ganom.customswapper;
import java.awt.*;
import java.lang.reflect.*;
import java.util.*;
import net.runelite.api.*;
import net.runelite.api.widgets.Widget;
import net.runelite.client.input.KeyManager;
import net.runelite.client.eventbus.EventBus;
public class MacroCheck {
 static <T>T mock(Class<T> c,java.util.function.BiFunction<String,Object[],Object> fn){return c.cast(Proxy.newProxyInstance(c.getClassLoader(),new Class[]{c},(p,m,a)->{Object v=fn.apply(m.getName(),a);if(v!=null)return v;if(m.getReturnType()==boolean.class)return false;if(m.getReturnType()==int.class)return 0;return null;}));}
 static void set(Object o,String name,Object value)throws Exception{Field f=CustomSwapper.class.getDeclaredField(name);f.setAccessible(true);f.set(o,value);}
 static java.awt.event.KeyEvent hotkeyEvent(Canvas canvas,int kind){return new java.awt.event.KeyEvent(canvas,kind,0,0,java.awt.event.KeyEvent.VK_F1,java.awt.event.KeyEvent.CHAR_UNDEFINED){@Override public int getExtendedKeyCode(){return java.awt.event.KeyEvent.VK_F1;}};}
 public static void main(String[]args)throws Exception {
  var actions=MacroAction.parse("// note\n123:equip\n123:remove\n123:equip\n218:47:cast\nprotect from magic:prayer\nspecial:enable");
  if(actions.size()!=6||!actions.get(3).parameter.equals("218:47")||actions.get(1).command!=MacroAction.Command.REMOVE)throw new AssertionError("sequence order");
  for(String invalid:new String[]{"bad","12:unknown","-1:equip","abc:clean"}){try{MacroAction.parse(invalid);throw new AssertionError("invalid accepted");}catch(IllegalArgumentException expected){}}
  if(CustomSwapper.tabKey(1)!=112||CustomSwapper.tabKey(12)!=123||CustomSwapper.tabKey(13)!=27||CustomSwapper.tabKey(0)!=0)throw new AssertionError("tab mapping");
  if(!CustomSwapper.screenPoint(new Rectangle(10,20,20,20),true,new Dimension(100,100),new Dimension(200,200)).equals(new java.awt.Point(40,60)))throw new AssertionError("stretched coordinates");
  Widget leaf=mock(Widget.class,(n,a)->n.equals("getItemId")?123:null);
  Widget root=mock(Widget.class,(n,a)->n.equals("getDynamicChildren")?new Widget[]{leaf}:null);
  if(CustomSwapper.find(root,w->w.getItemId()==123)!=leaf)throw new AssertionError("widget traversal");
  ItemContainer worn=mock(ItemContainer.class,(n,a)->n.equals("getItems")?new Item[]{new Item(11802,1),new Item(-1,0)}:null);
  Client gearClient=mock(Client.class,(n,a)->n.equals("getItemContainer")?worn:null);CustomSwapper gearPlugin=new CustomSwapper();set(gearPlugin,"client",gearClient);
  if(!gearPlugin.actionAlreadySatisfied(MacroAction.parse("11802:equip").get(0)))throw new AssertionError("already-worn gear must be skipped");
  if(gearPlugin.actionAlreadySatisfied(MacroAction.parse("123:equip").get(0)))throw new AssertionError("missing gear must still be equipped");
  if(gearPlugin.actionAlreadySatisfied(MacroAction.parse("11802:remove").get(0)))throw new AssertionError("remove action must not be skipped");
  if(gearPlugin.bounds(MacroAction.parse("11802:equip").get(0))!=null)throw new AssertionError("already-worn gear should not create a click target");
  Client client=mock(Client.class,(n,a)->{throw new AssertionError("Enable must not access game inputs: "+n);});
  var constructor=KeyManager.class.getDeclaredConstructor(Client.class,EventBus.class);constructor.setAccessible(true);
  KeyManager manager=constructor.newInstance(client,new EventBus());
  CustomSwapper plugin=new CustomSwapper();set(plugin,"keyManager",manager);plugin.startUp();
  Field listeners=KeyManager.class.getDeclaredField("keyListeners");listeners.setAccessible(true);
  if(((java.util.List<?>)listeners.get(manager)).size()!=10)throw new AssertionError("only ten configured hotkeys");
  Field task=CustomSwapper.class.getDeclaredField("pending");task.setAccessible(true);if(task.get(plugin)!=null)throw new AssertionError("enable executed sequence");
  var busyField=CustomSwapper.class.getDeclaredField("busy");busyField.setAccessible(true);var busy=(java.util.concurrent.atomic.AtomicBoolean)busyField.get(plugin);
  var generationField=CustomSwapper.class.getDeclaredField("generation");generationField.setAccessible(true);var generation=(java.util.concurrent.atomic.AtomicInteger)generationField.get(plugin);
  set(plugin,"config",mock(CustomSwapperConfig.class,(n,a)->n.startsWith("customSwap")?"":n.startsWith("custom")?net.runelite.client.config.Keybind.NOT_SET:null));
  Canvas canvas=new Canvas();int original=generation.get();busy.set(true);
  for(int kind:new int[]{java.awt.event.KeyEvent.KEY_PRESSED,java.awt.event.KeyEvent.KEY_RELEASED,java.awt.event.KeyEvent.KEY_TYPED}){
   var event=new java.awt.event.KeyEvent(canvas,kind,0,0,kind==java.awt.event.KeyEvent.KEY_TYPED?java.awt.event.KeyEvent.VK_UNDEFINED:java.awt.event.KeyEvent.VK_ESCAPE,kind==java.awt.event.KeyEvent.KEY_TYPED?(char)27:java.awt.event.KeyEvent.CHAR_UNDEFINED);
   for(Object listener:(java.util.List<?>)listeners.get(manager)){
    var key=(net.runelite.client.input.KeyListener)listener;
    if(kind==java.awt.event.KeyEvent.KEY_PRESSED)key.keyPressed(event);else if(kind==java.awt.event.KeyEvent.KEY_RELEASED)key.keyReleased(event);else key.keyTyped(event);
   }
   if(event.isConsumed()||!busy.get()||generation.get()!=original)throw new AssertionError("Escape must pass through without cancelling an active swap");
  }
  plugin.submit("");plugin.cancel();plugin.shutDown();if(!((java.util.List<?>)listeners.get(manager)).isEmpty())throw new AssertionError("listeners leaked");
  java.util.List<String> messages=new java.util.concurrent.CopyOnWriteArrayList<>();Canvas focused=new Canvas(){@Override public boolean isFocusOwner(){return true;}};
  Client engineClient=mock(Client.class,(n,a)->{switch(n){case "getGameState":return GameState.LOGGED_IN;case "isClientThread":return true;case "getCanvas":return focused;case "getVarcIntValue":return 3;case "getItemContainer":return worn;case "addChatMessage":messages.add((String)a[2]);return null;default:return null;}});
  CustomSwapper engine=new CustomSwapper();set(engine,"client",engineClient);set(engine,"keyManager",manager);set(engine,"clientThread",new net.runelite.client.callback.ClientThread(){@Override public void invokeLater(Runnable action){action.run();}});engine.startUp();engine.submit("11802:equip\n123:equip");
  ((java.util.concurrent.Future<?>)task.get(engine)).get(2,java.util.concurrent.TimeUnit.SECONDS);
  if(messages.stream().noneMatch(v->v.contains("123:equip")))throw new AssertionError("sequence must advance past worn gear to the next item");
  set(engine,"config",mock(CustomSwapperConfig.class,(n,a)->n.equals("customOne")?new net.runelite.client.config.Keybind(java.awt.event.KeyEvent.VK_F1,0):n.startsWith("customSwap")?"123:equip":n.startsWith("custom")?net.runelite.client.config.Keybind.NOT_SET:null));
  var hotkey=(net.runelite.client.input.KeyListener)((java.util.List<?>)listeners.get(manager)).get(0);
  var press=hotkeyEvent(focused,java.awt.event.KeyEvent.KEY_PRESSED);
  hotkey.keyPressed(hotkeyEvent(focused,java.awt.event.KeyEvent.KEY_PRESSED));var first=(java.util.concurrent.Future<?>)task.get(engine);first.get(2,java.util.concurrent.TimeUnit.SECONDS);
  hotkey.keyPressed(hotkeyEvent(focused,java.awt.event.KeyEvent.KEY_PRESSED));
  if(task.get(engine)!=first)throw new AssertionError("held hotkey repeated a completed sequence");
  hotkey.keyReleased(hotkeyEvent(focused,java.awt.event.KeyEvent.KEY_RELEASED));
  set(engine,"sendingInput",true);hotkey.keyPressed(hotkeyEvent(focused,java.awt.event.KeyEvent.KEY_PRESSED));set(engine,"sendingInput",false);if(task.get(engine)!=first)throw new AssertionError("synthetic input started a sequence");
  hotkey.keyPressed(hotkeyEvent(focused,java.awt.event.KeyEvent.KEY_PRESSED));var second=(java.util.concurrent.Future<?>)task.get(engine);second.get(2,java.util.concurrent.TimeUnit.SECONDS);if(second==first)throw new AssertionError("released key did not rearm");
  hotkey.focusLost();hotkey.keyPressed(hotkeyEvent(focused,java.awt.event.KeyEvent.KEY_PRESSED));((java.util.concurrent.Future<?>)task.get(engine)).get(2,java.util.concurrent.TimeUnit.SECONDS);if(task.get(engine)==second)throw new AssertionError("focus loss did not rearm");
  engine.shutDown();
  EquipmentPlan plan=new EquipmentPlan();plan.equip(3,1,true);plan.equip(3,2,false);plan.equip(5,3,false);
  if(!plan.missing(slot->slot==3?2:slot==5?3:-1).isEmpty())throw new AssertionError("replaced weapon/shield plan");
  plan.equip(3,4,true);if(!plan.missing(slot->slot==3?4:-1).isEmpty())throw new AssertionError("two-handed weapon must clear shield");
  plan.equip(5,3,false);if(!plan.missing(slot->slot==5?3:-1).isEmpty())throw new AssertionError("shield must clear two-handed weapon");
  plan.remove(5,3);if(!plan.missing(slot->-1).isEmpty())throw new AssertionError("removal confirmation");
  Widget[] gearWidgets=new Widget[8];for(int i=0;i<8;i++){final int itemId=100+i;gearWidgets[i]=mock(Widget.class,(n,a)->n.equals("getItemId")?itemId:n.equals("getBounds")?new Rectangle(0,0,20,20):null);}
  Widget inventory=mock(Widget.class,(n,a)->n.equals("getDynamicChildren")?gearWidgets:null);
  ItemContainer emptyWorn=mock(ItemContainer.class,(n,a)->n.equals("getItems")?new Item[14]:null);
  Client fastClient=mock(Client.class,(n,a)->{switch(n){case "getGameState":return GameState.LOGGED_IN;case "isClientThread":return true;case "getCanvas":return focused;case "getVarcIntValue":return 3;case "getItemContainer":return emptyWorn;case "getWidget":return inventory;case "addChatMessage":messages.add((String)a[2]);return null;default:return null;}});
  var clicks=new java.util.concurrent.atomic.AtomicInteger();
  CustomSwapper fast=new CustomSwapper(){@Override void click(Rectangle rectangle,int token){clicks.incrementAndGet();}@Override EquipmentPlan equipmentPlan(java.util.List<MacroAction> actions){EquipmentPlan desired=new EquipmentPlan();for(int i=0;i<8;i++)desired.equip(i,100+i,false);return desired;}};
  set(fast,"client",fastClient);set(fast,"keyManager",manager);set(fast,"clientThread",new net.runelite.client.callback.ClientThread(){@Override public void invokeLater(Runnable action){action.run();}});
  set(fast,"config",mock(CustomSwapperConfig.class,(n,a)->n.equals("randLow")?60:n.equals("randHigh")?70:null));fast.startUp();
  StringBuilder eight=new StringBuilder();for(int i=0;i<8;i++)eight.append(100+i).append(":equip\n");
  long began=System.nanoTime();fast.submit(eight.toString());((java.util.concurrent.Future<?>)task.get(fast)).get(1200,java.util.concurrent.TimeUnit.MILLISECONDS);
  long elapsed=java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-began);
  if(clicks.get()!=8||elapsed>=1200)throw new AssertionError("eight clicks blocked on equipment confirmation: "+elapsed+"ms");
  var fastBusy=(java.util.concurrent.atomic.AtomicBoolean)busyField.get(fast);if(fastBusy.get())throw new AssertionError("post-check blocks a new swap");
  var fastGeneration=(java.util.concurrent.atomic.AtomicInteger)generationField.get(fast);int token=fastGeneration.get();
  EquipmentPlan missingPlan=new EquipmentPlan();missingPlan.equip(3,999,false);int beforeMessages=messages.size();fast.verifyEquipment(missingPlan,token);
  if(messages.size()!=beforeMessages+1||!messages.get(messages.size()-1).contains("999:equip"))throw new AssertionError("missing final equipment must be reported");
  beforeMessages=messages.size();fast.verifyEquipment(missingPlan,token-1);if(messages.size()!=beforeMessages)throw new AssertionError("stale check must not report");
  set(fast,"sequenceDeadline",System.nanoTime()-1);var check=CustomSwapper.class.getDeclaredMethod("check",int.class);check.setAccessible(true);try{check.invoke(fast,token);throw new AssertionError("sequence deadline ignored");}catch(java.lang.reflect.InvocationTargetException expected){if(!expected.getCause().getMessage().contains("60-second"))throw expected;}
  fast.shutDown();System.out.println("Eight simulated gear clicks completed in "+elapsed+"ms at configured 60-70ms delays, with no equipment updates between clicks.");
  System.out.println("PASS: parser, tab mapping, scaling, widget traversal, ten hotkeys, Escape never cancels swaps or consumes inventory binding, nonblocking slot-aware final equipment check, two-handed replacements, eight-click timing, sequence deadline, held-key protection, synthetic-input protection, shutdown cancellation and cleanup. No mouse or keyboard events dispatched.");
 }
}

