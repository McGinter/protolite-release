# ProtoLite namespace update

Close RuneLite first and back up the installed loader, launcher config, managers and plugin JAR directories.

Replace the launcher loader and config using runtime/ProtoLiteLoader.jar and runtime/config.json. Install the matching main manager and replace every installed main plugin JAR by the same filename from plugins/. If you use the optional legacy manager, update it and its installed plugins from legacy-plugins/ as well. Keep your existing settings and credentials private; they are not part of this package. Avoid leaving duplicate old plugin JARs in active loading directories.

Every component must be updated together. The new loader main class is bu.protolite.runelite.LauncherHijack.
